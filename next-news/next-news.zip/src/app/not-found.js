export default function NotfoundPage() {
  return (
    <section id="home">
      <h1>Page Not Found</h1>
      <p>The page you're looking for does not exist.</p>
    </section>
  );
}
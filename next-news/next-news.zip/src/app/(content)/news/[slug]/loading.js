export default function LoadingNewsItem() {
  return <p>กำลังโหลดเนื้อหาข่าว...</p>;
}
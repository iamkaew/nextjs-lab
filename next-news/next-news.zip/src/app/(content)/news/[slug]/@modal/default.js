export default function ModalDefaultPage() {
  return null;
}
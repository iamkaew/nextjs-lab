export default function LoadingNews() {
  return <p>Loading latest news...</p>;
}
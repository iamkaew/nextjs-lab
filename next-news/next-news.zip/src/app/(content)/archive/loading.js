export default function LoadingNews() {
  return <p>Loading archived news...</p>;
}